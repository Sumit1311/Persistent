#ifndef VECTOR_H_
#define VECTOR_H_
#include <iostream>
template <class T>
class Vector
{
    T *arr;
    int size,capacity;
    public:
    Vector();
    Vector(int size);
    int get_capacity();
    int get_size();
    T& operator[](int i);
    //friend std::ostream& operator<<(std::ostream& os,Vector& v);
    T& at(int i);
    void push_back(T ele); 
    T pop_back();
    //int insert(int num,int position,int *arr);
};

#include "vector.cpp"
#endif


