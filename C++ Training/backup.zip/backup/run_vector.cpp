#include "vector.h"
#include <iostream>

template <typename T>
void print_vector(Vector<T> v);

int main()
{
    Vector<int> v(5);
    print_vector(v);
    for(int i=0;i<5;i++)
    {
        v[i]=1;
    }
    int ele=1;
    v.push_back(ele);
    std::cout<<"Current Capacity : "<<v.get_capacity()<<std::endl;
    std::cout<<"Current Size : "<<v.get_size()<<std::endl;
    //std::cout<<v;
    print_vector(v);
    std::cout<<"The popped element is : "<<v.pop_back()<<std::endl;
    //std::cout<<v;
    print_vector(v);
    std::cout<<"Current Capacity : "<<v.get_capacity()<<std::endl;
    std::cout<<"Current Size : "<<v.get_size()<<std::endl;
    /*int arr[4]={2,2,2,2};
    v.insert(4,2,arr);
    int arr1[6]={3,3,3,3,3};
    v.insert(6,2,arr1);
    std::cout<<v;
    std::cout<<"Current Capacity : "<<v.get_capacity()<<std::endl;
    std::cout<<"Current Size : "<<v.get_size()<<std::endl;*/
    return 1;
} 

template <typename T>
void print_vector(Vector<T> v)
{
    int size=v.get_size();
    std::cout<<"The array is : ";
    for(int i=0;i<size;i++)
    {
        std::cout<<v[i]<<",";
    }
    std::cout<<std::endl;

}
