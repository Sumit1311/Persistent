#include "vector.h"
#include <stdexcept> 
#include <iostream>

template <class T>
Vector<T>::Vector()
{
    this->capacity=5;
    this->size=0;
    this->arr=new T[this->capacity];
}

template <class T>
Vector<T>::Vector(int size)
{
    if(size <= 5)
    {
        this->capacity=5;
    }
    else
    {
        this->capacity=size;    
    }
    this->arr=new T[this->capacity];
    this->size=size;
}

template <class T>
T& Vector<T>::operator[](int index)
{  
    //return this->arr[index];
    return this->at(index);
}

template <class T>
T& Vector<T>::at(int index)
{
    if(index>=0 && index<this->size)
    {
        //std::cout<<"Accessing Element"<<index<<std::endl;
        return arr[index];
    }
    else
    {
        //std::cout<<"Index Out of Bound";
        throw std::out_of_range ("Index out of bound");
    }
}

template <class T>
void Vector<T>::push_back(T ele)
{
    if(this->size == this->capacity)
    {
        this->capacity=this->capacity+5;
        T *temp=new T[this->capacity];
        for(int i=0;i<this->size;i++)
        {
            temp[i]=this->arr[i];
        }
        delete[] this->arr;
        this->arr=temp;
    } 
    arr[this->size]=ele;
    this->size++;
}

template <class T>
T Vector<T>::pop_back()
{
    if(this->size == 0)
    {
        throw std::out_of_range("Index out of bound");
    }
    T temp=this->arr[this->size-1];
    this->size--;
    return temp;
}


/*template <class T>
std::ostream& operator<<(std::ostream& os,Vector<T>& v)
{
    os<<"The array is : "<<std::endl;
    for(int i=0;i<v.size;i++)
    {
        os<<v[i]<<",";
    }
    os<<std::endl;
}*/

template <class T>
int Vector<T>::get_capacity()
{
    return capacity;
}

template <class T>
int Vector<T>::get_size()
{
    return this->size;
}

/*int Vector::insert(int num, int position, int *arr)
{
    //position is index of element after which the elements need to be inserted
    if(position > size - 1)
    {
        throw std::out_of_range("Index out of bound");
    }
    if(size+num > capacity)
    {
        this->capacity=size+num+5;
        int *temp=new int[this->capacity];
        for(int i=0;i<this->size;i++)
        {
            temp[i]=this->arr[i];
        }
        delete[] this->arr;
        this->arr=temp;
    }
    
    int new_end=size+num-1;
    int old_end=size-1;
    while(old_end > position)
    {
        this->arr[new_end]=this->arr[old_end];
        new_end--;
        old_end--;
    }
    for(int i=1;i<=num;i++)
    {
        this->arr[position+i]=arr[i-1];
    }
    size=size+num;
}*/
